package com.company;

public enum Payment {
    Paid,Refunded,
}
