package com.company;

public enum VipStatus {
    isVip,
    notVip,
}
