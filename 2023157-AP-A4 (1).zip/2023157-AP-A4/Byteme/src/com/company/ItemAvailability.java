package com.company;

public enum ItemAvailability {
    isAvailable,
    isNotAvailable,


}
