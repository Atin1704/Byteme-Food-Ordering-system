package com.company;

public enum FoodCategory {
    Snacks,
    Beverages,
    Sides,
    Deserts,
    MainCourse

}
