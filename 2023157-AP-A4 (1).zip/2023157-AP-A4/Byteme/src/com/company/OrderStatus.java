package com.company;

public enum OrderStatus {
    pending,submitted,accepted,delivered,cancelled,denied,

}
